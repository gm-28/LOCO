package com.example.locofx;

public class User {
    public String username;
    public String dir;
}
